% Quadruple Tank Problem
% This program calculates steady state heights, Transfer functions, PI
% controller parameters for different cases.
% After calculating these values, it updates the simulink model "tank4".
% %
% Wriiten by Prof A N Samanta for PDC class
%
prompt = 'Select Case(1/2/3): ';
n=0;
choice=[1,2,3,4,5];
while ~ismember(n,choice)
n = input(prompt);
switch n
    case 1
        % Minimum Phase
        k1 = 3.33; k2 = 3.35;
        r1 = 0.7;  r2 = 0.6;
        v1 = 3.0;  v2 = 3.0;
    case 2
        % Non-Minimum Phase
        k1 = 3.14; k2 = 3.29;
        r1 = 0.43;  r2 = 0.34;     
        v1 = 3.15;  v2 = 3.15;
    case 3
        % Minimum Phase
        k1 = 3.2; k2 = 3.32;
        r1 = 0.5;  r2 = 0.5;     
        v1 = 3.1;  v2 = 3.1;
    case 4
        % Zero at origin
        k1 = 3.33; k2 = 3.35;
        r1 = 0.6;  r2 = 0.4;
        v1 = 3.0;  v2 = 3.0;
   case 5
        % Zero at origin
        k1 = 3.14; k2 = 3.29;
        r1 = 0.5;  r2 = 0.5;     
        v1 = 3.15;  v2 = 3.15;  
    otherwise
        disp('Wrong Case No')
end
end
hs=fsolve(@(x) qtss(x,v1,v2,r1,r2,k1,k2),[5;5;5;5]);
fprintf('Steady State heights for tank1 =%f tank2 = %f tank3 = %f tank4 = %f\n',hs);
[A,B,C,D,gs,Z]=qtstate(hs,r1,r2,k1,k2);
disp("The transfer function is");
gs
disp("Zero of the system");
Z
load_system('tank4');
set_param('tank4/Quad Tank','r1',string(r1),'r2',string(r2));
set_param('tank4/Quad Tank','k1',string(k1),'k2',string(k2));
str=compose('[%f;%f;%f;%f]',hs');
set_param('tank4/Quad Tank','h0',str{1});
set_param('tank4/h1sp','Value',string(hs(1)));
set_param('tank4/h2sp','Value',string(hs(2)));
set_param('tank4/bias','Value',string(v1));
% level 1 controller (IMC-PI with 30% of time constant)
tao=gs(1,1).den{1}(1)
kc=1/gs(1,1).num{1}(2)/0.3
set_param('tank4/Controller','P',string(kc),'I',string(1/tao));
% level 2 controller (IMC-PI with 30% of time constant)
tao=gs(2,2).den{1}(1)
kc=1/gs(2,2).num{1}(2)/0.3
set_param('tank4/Controller1','P',string(kc),'I',string(1/tao));
% x0(3)=kc; x0(4)=1/tao;
open_system('tank4');
% x=fminunc(@optqt,x0);


function IAE=optqt(x)
set_param('tank4/Controller','P',string(x(1)),'I',string(x(2)));
set_param('tank4/Controller1','P',string(x(3)),'I',string(x(4)));
sim('tank4');
IAE=iae(end);
end
function [A,B,C,D,gs,zero]=qtstate(h,r1,r2,k1,k2)
        A1=28;
        A2=32;
        A3=28;
        A4=32;
        a1=0.071;
        a2=0.057;
        a3=0.071;
        a4=0.057;
        g=981;
        km=0.8;
        T1=A1/a1*sqrt(2*h(1)/g);
        T2=A2/a2*sqrt(2*h(2)/g);
        T3=A3/a3*sqrt(2*h(3)/g);
        T4=A4/a4*sqrt(2*h(4)/g);
        A=[-1/T1 0 A3/(A1*T3) 0; 0 -1/T2 0 A4/(A2*T4); 0 0 -1/T3 0; ...
            0 0 0  -1/T4];
        B=[r1*k1/A1 0; 0 r2*k2/A2; 0 (1-r2)*k2/A3; (1-r1)*k1/A4 0];
        C=[km 0 0 0; 0 km 0 0];
        D=[0 0;0 0];
        c1=(T1*k1*km)/A1;
        c2=(T2*k2*km)/A2;
        s=tf('s');
        gs=[r1*c1/(T1*s+1) (1-r2)*c2/((T1*s+1)*(T3*s+1));...
            (1-r1)*c1/((T2*s+1)*(T4*s+1))  r2*c2/(T2*s+1)];
        det_g=minreal(gs(1,1)*gs(2,2)-gs(1,2)*gs(2,1));
        zero=roots(det_g.num{1});
end    
function f = qtss(x,v1,v2,r1,r2,k1,k2) 
        A1=28;
        A2=32;
        A3=28;
        A4=32;
        a1=0.071;
        a2=0.057;
        a3=0.071;
        a4=0.057;
        g=981;
        % Parameters end
         
        % State derivatives under flag 1 in terms of input parameters and
        % input
        h1=x(1);h2=x(2);h3=x(3);h4=x(4);
        v1=3.0; v2=3.0;
        F1 = k1*v1;
        F2 = k2*v2;
        f(1)=(r1*F1)/A1 - (a1/A1)*sqrt(2*g*h1) + (a3/A1)*sqrt(2*g*h3);
        f(2)=(r2*F2)/A2 - (a2/A2)*sqrt(2*g*h2) + (a4/A2)*sqrt(2*g*h4);
        f(3)=(F2/A3)*(1-r2) -(a3/A3)*sqrt(2*g*h3);
        f(4)=(F1/A4)*(1-r1) -(a4/A4)*sqrt(2*g*h4);
end
